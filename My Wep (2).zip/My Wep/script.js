// ===== CURRENCY DATA =====
const CURRENCIES = [
  { code: 'USD', name: 'US Dollar' },
  { code: 'EUR', name: 'Euro' },
  { code: 'GBP', name: 'British Pound' },
  { code: 'JPY', name: 'Japanese Yen' },
  { code: 'AUD', name: 'Australian Dollar' },
  { code: 'CAD', name: 'Canadian Dollar' },
  { code: 'CHF', name: 'Swiss Franc' },
  { code: 'CNY', name: 'Chinese Yuan' },
  { code: 'INR', name: 'Indian Rupee' },
  { code: 'MXN', name: 'Mexican Peso' },
  { code: 'BRL', name: 'Brazilian Real' },
  { code: 'KRW', name: 'South Korean Won' },
  { code: 'SGD', name: 'Singapore Dollar' },
  { code: 'HKD', name: 'Hong Kong Dollar' },
  { code: 'NOK', name: 'Norwegian Krone' },
  { code: 'SEK', name: 'Swedish Krona' },
  { code: 'DKK', name: 'Danish Krone' },
  { code: 'NZD', name: 'New Zealand Dollar' },
  { code: 'ZAR', name: 'South African Rand' },
  { code: 'TRY', name: 'Turkish Lira' },
  { code: 'PLN', name: 'Polish Zloty' },
  { code: 'THB', name: 'Thai Baht' },
  { code: 'IDR', name: 'Indonesian Rupiah' },
  { code: 'MYR', name: 'Malaysian Ringgit' },
  { code: 'PHP', name: 'Philippine Peso' },
  { code: 'ILS', name: 'Israeli Shekel' },
  { code: 'AED', name: 'UAE Dirham' },
  { code: 'SAR', name: 'Saudi Riyal' },
  { code: 'EGP', name: 'Egyptian Pound' },
  { code: 'NGN', name: 'Nigerian Naira' },
  { code: 'PKR', name: 'Pakistani Rupee' },
  { code: 'VND', name: 'Vietnamese Dong' },
  { code: 'ARS', name: 'Argentine Peso' },
  { code: 'TWD', name: 'Taiwan Dollar' },
  { code: 'KWD', name: 'Kuwaiti Dinar' },
  { code: 'QAR', name: 'Qatari Riyal' },
  { code: 'HUF', name: 'Hungarian Forint' },
  { code: 'RON', name: 'Romanian Leu' },
  { code: 'UAH', name: 'Ukrainian Hryvnia' },
  { code: 'PEN', name: 'Peruvian Sol' },
  { code: 'MAD', name: 'Moroccan Dirham' },
];

// ===== STATE =====
let fromCurrency = 'USD';
let toCurrency   = 'EUR';
let currentRates = {};
let currentRate  = null;
let selectorTarget = null;

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  buildCurrencyList();
  fetchRates();
  document.getElementById('from-input').value = '1';
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeSelector();
  });
});

// ===== FETCH RATES =====
async function fetchRates() {
  const icon = document.getElementById('refresh-icon');
  icon.classList.add('spinning');

  const res = await fetch('https://api.exchangerate-api.com/v4/latest/' + fromCurrency);
  const data = await res.json();
  currentRates = data.rates;
  currentRate  = currentRates[toCurrency] || null;

  icon.classList.remove('spinning');
  updateUI();

  document.getElementById('rate-time').textContent =
    'Updated ' + new Date().toLocaleTimeString();
  buildChart(currentRate);
}

// ===== UPDATE UI =====
function updateUI() {
  if (!currentRate) return;
  const fromVal = parseFloat(document.getElementById('from-input').value) || 0;
  document.getElementById('to-input').value = formatNum(fromVal * currentRate);
  document.getElementById('rate-text').textContent =
    '1 ' + fromCurrency + ' = ' + formatNum(currentRate) + ' ' + toCurrency;
  document.getElementById('from-code').textContent = fromCurrency;
  document.getElementById('to-code').textContent   = toCurrency;
  const fromObj = CURRENCIES.find(c => c.code === fromCurrency);
  const toObj   = CURRENCIES.find(c => c.code === toCurrency);
  document.getElementById('from-name').textContent = fromObj ? fromObj.name : '';
  document.getElementById('to-name').textContent   = toObj ? toObj.name : '';
}

function formatNum(n) {
  if (!n || isNaN(n)) return '0';
  if (n < 0.01) return n.toFixed(6);
  if (n < 1)    return n.toFixed(4);
  if (n > 1e6)  return n.toLocaleString('en-US', { maximumFractionDigits: 2 });
  return n.toFixed(2);
}

// ===== FROM INPUT CHANGE =====
function onFromChange() {
  if (!currentRate) return;
  const val = parseFloat(document.getElementById('from-input').value) || 0;
  document.getElementById('to-input').value = val ? formatNum(val * currentRate) : '';
}

// ===== SWAP =====
function swapCurrencies() {
  [fromCurrency, toCurrency] = [toCurrency, fromCurrency];
  const btn = document.getElementById('swap-btn');
  btn.classList.add('spinning');
  setTimeout(() => btn.classList.remove('spinning'), 500);
  const toVal = document.getElementById('to-input').value;
  document.getElementById('from-input').value = toVal || '1';
  fetchRates();
}

// ===== SET PAIR =====
function setPair(from, to) {
  fromCurrency = from;
  toCurrency   = to;
  document.getElementById('from-input').value = '1';
  fetchRates();
}

// ===== CURRENCY SELECTOR =====
function openSelector(target) {
  selectorTarget = target;
  document.getElementById('overlay').classList.add('active');
  document.getElementById('search-input').value = '';
  filterCurrencies();
  setTimeout(() => document.getElementById('search-input').focus(), 100);
}
function closeSelector() {
  document.getElementById('overlay').classList.remove('active');
  selectorTarget = null;
}
function selectCurrency(code) {
  if (selectorTarget === 'from') {
    if (code === toCurrency) toCurrency = fromCurrency;
    fromCurrency = code;
  } else {
    if (code === fromCurrency) fromCurrency = toCurrency;
    toCurrency = code;
  }
  closeSelector();
  document.getElementById('from-input').value = '1';
  fetchRates();
}

// ===== BUILD CURRENCY LIST =====
function buildCurrencyList(filter = '') {
  const list = document.getElementById('currency-list');
  const filtered = CURRENCIES.filter(c =>
    c.code.toLowerCase().includes(filter.toLowerCase()) ||
    c.name.toLowerCase().includes(filter.toLowerCase())
  );
  list.innerHTML = filtered.map(c => `
    <button class="currency-item" onclick="selectCurrency('${c.code}')">
      <div class="currency-icon">${c.code.slice(0,2)}</div>
      <div>
        <div class="currency-code">${c.code}</div>
        <div class="currency-full-name">${c.name}</div>
      </div>
    </button>
  `).join('');
  if (filtered.length === 0) {
    list.innerHTML = '<p style="text-align:center;color:#4a5568;padding:2rem">No currencies found</p>';
  }
}
function filterCurrencies() {
  buildCurrencyList(document.getElementById('search-input').value);
}

// ===== CHART =====
function buildChart(rate) {
  if (!rate) return;
  const card = document.getElementById('chart-card');
  card.style.display = 'block';

  // Simulate 28-point trend data
  const data = [];
  const vol  = rate * 0.015;
  let val    = rate - vol * 3;
  for (let i = 0; i < 28; i++) {
    val += (Math.random() - 0.48) * vol;
    val = Math.max(val, rate * 0.96);
    val = Math.min(val, rate * 1.04);
    data.push(val);
  }
  data[data.length - 1] = rate;

  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const W = 800, H = 120, P = 4;

  const pts = data.map((v, i) => ({
    x: (i / (data.length - 1)) * W,
    y: H - P - ((v - min) / range) * (H - P * 2)
  }));

  const linePath = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaPath = linePath + ` L ${W} ${H} L 0 ${H} Z`;

  const isPos   = data[data.length - 1] >= data[0];
  const color   = isPos ? '#00FF94' : '#ff4d4d';
  const pct     = ((data[data.length - 1] - data[0]) / data[0] * 100).toFixed(2);
  const changeEl = document.getElementById('chart-change');
  changeEl.textContent = (isPos ? '+' : '') + pct + '%';
  changeEl.className = 'chart-change' + (isPos ? '' : ' negative');

  document.getElementById('sparkline').innerHTML = `
    <defs>
      <linearGradient id="sg" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="${color}" stop-opacity="0.25"/>
        <stop offset="100%" stop-color="${color}" stop-opacity="0"/>
      </linearGradient>
    </defs>
    <path d="${areaPath}" fill="url(#sg)"/>
    <path d="${linePath}" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round"/>
  `;
}